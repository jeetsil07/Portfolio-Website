<?php
    echo 'This is an empty page';
?>